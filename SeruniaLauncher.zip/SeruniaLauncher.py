#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import sys
import time
import tempfile
import zipfile
import threading
import subprocess
from tkinter import Tk, Button, Label, messagebox, StringVar, NORMAL, DISABLED

try:
    import requests
except ImportError:
    raise SystemExit("Le module 'requests' est requis. Installe-le avec: pip install requests")

# ================== CONFIG ==================
APP_NAME = "Sérunia - Launcher"
DEFAULT_LOCAL_VERSION = "1.0.0"

# Ton dépôt GitHub (modifie si ton nom change)
REMOTE_VERSION_URL = "https://raw.githubusercontent.com/merciertr17/SeruniaLauncher/main/version.txt"
REMOTE_ZIP_URL = "https://raw.githubusercontent.com/merciertr17/SeruniaLauncher/main/SeruniaContent.zip"

CONTENT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "content")
LOCAL_VERSION_FILE = os.path.join(CONTENT_DIR, "version.txt")
# ============================================


def ensure_dirs():
    os.makedirs(CONTENT_DIR, exist_ok=True)


def read_local_version():
    try:
        with open(LOCAL_VERSION_FILE, "r", encoding="utf-8") as f:
            return f.read().strip()
    except FileNotFoundError:
        return DEFAULT_LOCAL_VERSION


def write_local_version(version: str):
    with open(LOCAL_VERSION_FILE, "w", encoding="utf-8") as f:
        f.write(version.strip())


def parse_semver(v: str):
    parts = []
    for p in v.strip().lower().lstrip("v").split("."):
        try:
            parts.append(int(p))
        except ValueError:
            parts.append(0)
    while len(parts) < 3:
        parts.append(0)
    return tuple(parts[:3])


def is_newer(remote: str, local: str) -> bool:
    return parse_semver(remote) > parse_semver(local)


def get_remote_version():
    r = requests.get(REMOTE_VERSION_URL, timeout=10)
    r.raise_for_status()
    return r.text.strip()


def download_remote_zip(progress_cb=None):
    headers = {"User-Agent": APP_NAME}
    with requests.get(REMOTE_ZIP_URL, headers=headers, stream=True, timeout=60) as r:
        r.raise_for_status()
        total = int(r.headers.get("Content-Length", 0))
        downloaded = 0
        fd, tmp_path = tempfile.mkstemp(prefix="serunia_", suffix=".zip")
        os.close(fd)
        with open(tmp_path, "wb") as f:
            for chunk in r.iter_content(8192):
                if chunk:
                    f.write(chunk)
                    downloaded += len(chunk)
                    if progress_cb and total > 0:
                        progress_cb(downloaded, total)
    return tmp_path


def extract_zip(zip_path, dest_dir):
    with zipfile.ZipFile(zip_path, "r") as zf:
        for member in zf.infolist():
            extracted_path = os.path.normpath(os.path.join(dest_dir, member.filename))
            if not extracted_path.startswith(os.path.normpath(dest_dir)):
                continue
            zf.extract(member, dest_dir)


def relaunch():
    python = sys.executable
    args = [python] + sys.argv
    try:
        subprocess.Popen(args, cwd=os.path.dirname(os.path.abspath(__file__)))
    except Exception:
        pass
    os._exit(0)


class LauncherUI:
    def __init__(self, root: Tk):
        self.root = root
        self.root.title(APP_NAME)
        self.root.geometry("380x230")
        self.root.resizable(False, False)

        self.status_var = StringVar(value="Prêt.")
        self.version_var = StringVar(value=f"Version locale : {read_local_version()}")

        self.btn_check = Button(root, text="Vérifier les mises à jour", width=28, command=self.on_check_click)
        self.btn_play = Button(root, text="Jouer", width=28, state=NORMAL, command=self.on_play_click)
        self.btn_opts = Button(root, text="Paramètres", width=28, state=NORMAL, command=self.on_opts_click)

        self.lbl_status = Label(root, textvariable=self.status_var, anchor="w")
        self.lbl_version = Label(root, textvariable=self.version_var, anchor="w")

        self.btn_check.pack(pady=14)
        self.btn_play.pack(pady=4)
        self.btn_opts.pack(pady=4)
        Label(root, text="").pack(pady=2)
        self.lbl_status.pack(padx=12, anchor="w")
        self.lbl_version.pack(padx=12, anchor="w")

    def set_busy(self, busy: bool):
        state = DISABLED if busy else NORMAL
        self.btn_check.config(state=state)
        self.btn_play.config(state=state)
        self.btn_opts.config(state=state)

    def on_play_click(self):
        messagebox.showinfo("Jouer", "La fonction 'Jouer' n'est pas encore active.")

    def on_opts_click(self):
        messagebox.showinfo("Paramètres", "L'onglet 'Paramètres' n'est pas encore disponible.")

    def on_check_click(self):
        self.set_busy(True)
        self.status_var.set("Vérification des mises à jour...")
        t = threading.Thread(target=self._update_thread, daemon=True)
        t.start()

    def _update_thread(self):
        try:
            ensure_dirs()
            local_version = read_local_version()
            remote_version = get_remote_version()

            if not is_newer(remote_version, local_version):
                self._ui_status("Aucune mise à jour disponible.")
                return

            self._ui_status(f"Nouvelle version {remote_version} trouvée... Téléchargement.")
            zip_path = download_remote_zip(lambda d, t: self._ui_status(f"Téléchargement... {int(d*100/t)}%"))
            extract_zip(zip_path, CONTENT_DIR)
            write_local_version(remote_version)

            try:
                os.remove(zip_path)
            except Exception:
                pass

            self._ui_status("Mise à jour terminée. Relancement...")
            time.sleep(1)
            relaunch()

        except Exception as e:
            self._ui_status(f"Erreur : {e}")
            messagebox.showerror("Erreur de mise à jour", str(e))
        finally:
            self.set_busy(False)

    def _ui_status(self, text):
        self.root.after(0, lambda: self.status_var.set(text))


def main():
    ensure_dirs()
    root = Tk()
    LauncherUI(root)
    root.mainloop()


if __name__ == "__main__":
    main()
